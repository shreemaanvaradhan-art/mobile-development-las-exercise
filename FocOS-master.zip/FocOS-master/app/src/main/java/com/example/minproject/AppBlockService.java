package com.example.minproject;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class AppBlockService extends AccessibilityService {

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Toast.makeText(this, "Focus App Service Active", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences prefs = getSharedPreferences("focus_prefs", MODE_PRIVATE);
        if (!prefs.getBoolean("focus_mode", false)) return;

        if (event == null || event.getPackageName() == null) return;

        String pkg = event.getPackageName().toString().toLowerCase();

        // Ignore system apps, launcher and this app itself
        if (pkg.equals(getPackageName()) || 
            pkg.contains("launcher") || 
            pkg.contains("systemui") || 
            pkg.contains("android.settings") ||
            pkg.contains("com.google.android.packageinstaller") ||
            pkg.contains("com.android.permissioncontroller")) {
            return;
        }

        // Specific checks for apps
        boolean isControlled = false;
        boolean isAllowed = false;

        if (pkg.contains("whatsapp")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_whatsapp", false);
        } else if (pkg.contains("outlook")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_outlook", false);
        } else if (pkg.contains("email") || pkg.contains("gmail") || pkg.contains("mail")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_email", false);
        } else if (pkg.contains("contact") || pkg.contains("people")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_contact", false);
        } else if (pkg.contains("dialer") || pkg.contains("phone") || pkg.contains("telecom")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_phone", false);
        } else if (pkg.contains("camera")) {
            isControlled = true;
            isAllowed = prefs.getBoolean("allow_camera", false);
        }

        // If it's a controlled app and not allowed, block it.
        // If it's NOT a controlled app, and Focus Mode is ON, block it too.
        if (!isControlled || !isAllowed) {
            blockApp();
        }
    }

    private void blockApp() {
        new Handler(getMainLooper()).post(() ->
                Toast.makeText(getApplicationContext(), "Blocked by Focus Mode", Toast.LENGTH_SHORT).show()
        );
        performGlobalAction(GLOBAL_ACTION_HOME);
    }

    @Override
    public void onInterrupt() {
    }
}