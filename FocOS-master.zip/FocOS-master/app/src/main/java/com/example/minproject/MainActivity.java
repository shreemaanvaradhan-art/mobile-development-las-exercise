package com.example.minproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView timeText;
    Button focusBtn;
    Button btnWhatsapp, btnOutlook, btnEmail, btnContact, btnPhone, btnCamera;
    boolean focusMode;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("focus_prefs", MODE_PRIVATE);

        timeText = findViewById(R.id.timeText);
        focusBtn = findViewById(R.id.focusBtn);
        btnWhatsapp = findViewById(R.id.btnWhatsapp);
        btnOutlook = findViewById(R.id.btnOutlook);
        btnEmail = findViewById(R.id.btnEmail);
        btnContact = findViewById(R.id.btnContact);
        btnPhone = findViewById(R.id.btnPhone);
        btnCamera = findViewById(R.id.btnCamera);

        // LOAD saved state
        focusMode = prefs.getBoolean("focus_mode", false);
        updateFocusButton();

        // Setup app buttons with just the label
        setupAppButton(btnWhatsapp, "whatsapp", "WhatsApp", "com.whatsapp");
        setupAppButton(btnOutlook, "outlook", "Outlook", "com.microsoft.office.outlook");
        setupAppButton(btnEmail, "email", "Email", "com.google.android.gm");
        setupAppButton(btnContact, "contact", "Contacts", "com.android.contacts");
        setupAppButton(btnPhone, "phone", "Phone", "com.android.dialer");
        setupAppButton(btnCamera, "camera", "Camera", null);

        updateTime();

        focusBtn.setOnClickListener(v -> {
            focusMode = !focusMode;
            updateFocusButton();
            prefs.edit().putBoolean("focus_mode", focusMode).apply();
        });
    }

    private void setupAppButton(Button button, String key, String label, String packageName) {
        boolean isAllowed = prefs.getBoolean("allow_" + key, false);
        updateAppButtonText(button, label, isAllowed);

        button.setOnClickListener(v -> {
            boolean current = prefs.getBoolean("allow_" + key, false);
            boolean newValue = !current;
            prefs.edit().putBoolean("allow_" + key, newValue).apply();
            updateAppButtonText(button, label, newValue);

            if (newValue) {
                if (key.equals("camera")) {
                    launchCamera();
                } else if (key.equals("phone")) {
                    launchPhone();
                } else if (packageName != null) {
                    launchApp(packageName);
                }
            }
        });
    }

    private void launchApp(String packageName) {
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        if (intent != null) {
            startActivity(intent);
        } else {
            if (packageName.equals("com.whatsapp")) {
                intent = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                if (intent != null) {
                    startActivity(intent);
                    return;
                }
            }
            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchCamera() {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
        startActivity(intent);
    }

    private void launchPhone() {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        startActivity(intent);
    }

    private void updateAppButtonText(Button button, String label, boolean isAllowed) {
        // Removed ON/OFF, now just shows the label
        button.setText(label);
        // Using slightly different shades of black to indicate state
        button.setBackgroundColor(isAllowed ? 0xFF333333 : 0xFF222222); 
        button.setTextColor(0xFFFFFFFF);
    }

    private void updateFocusButton() {
        focusBtn.setText("Focus Mode: " + (focusMode ? "ON" : "OFF"));
        focusBtn.setBackgroundColor(focusMode ? 0xFF2196F3 : 0xFF333333);
        focusBtn.setTextColor(0xFFFFFFFF);
    }

    private void updateTime() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                timeText.setText(time);
                handler.postDelayed(this, 1000);
            }
        }, 0);
    }
}